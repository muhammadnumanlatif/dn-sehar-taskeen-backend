__turbopack_load_page_chunks__("/_error", [
  "static/chunks/4510ce5a18e60fee.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-04e56b5909cd0d36.js"
])

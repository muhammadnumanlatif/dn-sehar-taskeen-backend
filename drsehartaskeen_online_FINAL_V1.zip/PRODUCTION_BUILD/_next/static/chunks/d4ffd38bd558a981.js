__turbopack_load_page_chunks__("/About", [
  "static/chunks/06e0408a94da585e.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/turbopack-0b755d2ecc02ca5b.js"
])

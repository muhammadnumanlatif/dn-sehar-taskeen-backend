__turbopack_load_page_chunks__("/Quote", [
  "static/chunks/23be39f2849310d9.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/turbopack-5cd90219866a9194.js"
])

__turbopack_load_page_chunks__("/_error", [
  "static/chunks/4510ce5a18e60fee.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-930424d351da1467.js"
])

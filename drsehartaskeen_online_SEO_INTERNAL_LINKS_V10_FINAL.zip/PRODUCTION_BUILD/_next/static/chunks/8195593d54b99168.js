__turbopack_load_page_chunks__("/Services", [
  "static/chunks/dbedb8558e551e43.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/turbopack-544d7718f519885c.js"
])

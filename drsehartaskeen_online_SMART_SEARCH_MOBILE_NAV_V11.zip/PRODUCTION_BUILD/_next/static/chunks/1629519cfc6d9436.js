__turbopack_load_page_chunks__("/Home", [
  "static/chunks/fbbbfb0227b01d1d.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/turbopack-c190dd2bdcef6b47.js"
])

__turbopack_load_page_chunks__("/_app", [
  "static/chunks/cce8aebb9c30e3e9.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-09d31b3228853241.js"
])

__turbopack_load_page_chunks__("/Quote", [
  "static/chunks/abbca628eaa6ae9f.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/turbopack-3ce1277ac95df17a.js"
])

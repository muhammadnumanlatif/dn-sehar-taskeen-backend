__turbopack_load_page_chunks__("/About", [
  "static/chunks/06e0408a94da585e.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/turbopack-dc4c630ea013cd52.js"
])

__turbopack_load_page_chunks__("/Terms", [
  "static/chunks/3085e8c367e1cdad.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-9da3d1768b0fef3c.js"
])

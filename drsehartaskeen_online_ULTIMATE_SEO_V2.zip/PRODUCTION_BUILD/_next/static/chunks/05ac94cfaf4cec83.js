__turbopack_load_page_chunks__("/Services", [
  "static/chunks/dbedb8558e551e43.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/turbopack-b61719dd700bd94d.js"
])

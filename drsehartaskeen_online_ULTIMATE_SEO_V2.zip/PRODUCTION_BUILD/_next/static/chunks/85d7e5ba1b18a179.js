__turbopack_load_page_chunks__("/Courses", [
  "static/chunks/e1123036b575963f.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/turbopack-fa2af1116c4615d8.js"
])

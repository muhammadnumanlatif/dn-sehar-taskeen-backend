__turbopack_load_page_chunks__("/_app", [
  "static/chunks/cce8aebb9c30e3e9.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-8c702a170c8a9164.js"
])

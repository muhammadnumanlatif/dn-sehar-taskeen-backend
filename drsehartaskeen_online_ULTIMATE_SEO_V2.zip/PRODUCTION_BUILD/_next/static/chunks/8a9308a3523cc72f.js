__turbopack_load_page_chunks__("/PrivacyPolicy", [
  "static/chunks/6a7fd0dd41faa325.js",
  "static/chunks/17eb32efe7723612.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-bc7f7f6328f08703.js"
])

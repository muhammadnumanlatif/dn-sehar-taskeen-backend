self.__BUILD_MANIFEST = {
  "/About": [
    "static/chunks/d4ffd38bd558a981.js"
  ],
  "/Courses": [
    "static/chunks/85d7e5ba1b18a179.js"
  ],
  "/Home": [
    "static/chunks/5a544c44472e5a52.js"
  ],
  "/PrivacyPolicy": [
    "static/chunks/8a9308a3523cc72f.js"
  ],
  "/Quote": [
    "static/chunks/db330d39fd1a7c14.js"
  ],
  "/Services": [
    "static/chunks/05ac94cfaf4cec83.js"
  ],
  "/Sessions": [
    "static/chunks/9b14f83472e11a53.js"
  ],
  "/Terms": [
    "static/chunks/c32d43c2c74bed1e.js"
  ],
  "/_error": [
    "static/chunks/20d5b43d7959cd63.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/About",
    "/Courses",
    "/Home",
    "/PrivacyPolicy",
    "/Quote",
    "/Services",
    "/Sessions",
    "/Terms",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()
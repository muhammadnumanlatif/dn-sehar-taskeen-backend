__turbopack_load_page_chunks__("/Terms", [
  "static/chunks/3085e8c367e1cdad.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-2a1ac5290f75ed11.js"
])

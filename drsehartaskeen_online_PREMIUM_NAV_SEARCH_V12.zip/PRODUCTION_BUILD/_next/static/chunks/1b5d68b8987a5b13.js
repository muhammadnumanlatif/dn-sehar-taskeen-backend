__turbopack_load_page_chunks__("/Courses", [
  "static/chunks/e1123036b575963f.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/aef5f4f7fcd63cd8.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/turbopack-5537286e04813d77.js"
])

self.__BUILD_MANIFEST = {
  "/About": [
    "static/chunks/ab46a050d6749e45.js"
  ],
  "/Courses": [
    "static/chunks/1b5d68b8987a5b13.js"
  ],
  "/DataDeletion": [
    "static/chunks/80d36fdee9226746.js"
  ],
  "/Home": [
    "static/chunks/1629519cfc6d9436.js"
  ],
  "/PrivacyPolicy": [
    "static/chunks/8e67f0f15c4dd473.js"
  ],
  "/Quote": [
    "static/chunks/6e2de89b0001f444.js"
  ],
  "/Services": [
    "static/chunks/8195593d54b99168.js"
  ],
  "/Sessions": [
    "static/chunks/d4730c231de2e058.js"
  ],
  "/Terms": [
    "static/chunks/d66cb82262dd8da5.js"
  ],
  "/_error": [
    "static/chunks/d6f05d0a852a276f.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/About",
    "/Courses",
    "/DataDeletion",
    "/Home",
    "/PrivacyPolicy",
    "/Quote",
    "/Services",
    "/Sessions",
    "/Terms",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()
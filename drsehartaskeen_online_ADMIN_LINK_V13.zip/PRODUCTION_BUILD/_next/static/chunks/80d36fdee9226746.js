__turbopack_load_page_chunks__("/DataDeletion", [
  "static/chunks/fab3c0a149d5491e.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-1f779bc0335da859.js"
])

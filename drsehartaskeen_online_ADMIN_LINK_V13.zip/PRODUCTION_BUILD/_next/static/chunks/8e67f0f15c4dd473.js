__turbopack_load_page_chunks__("/PrivacyPolicy", [
  "static/chunks/ea6114ab71888f1b.js",
  "static/chunks/13739531763dfdea.js",
  "static/chunks/481ad5f2111038cd.js",
  "static/chunks/turbopack-4f3a2a9f15c29b5e.js"
])
